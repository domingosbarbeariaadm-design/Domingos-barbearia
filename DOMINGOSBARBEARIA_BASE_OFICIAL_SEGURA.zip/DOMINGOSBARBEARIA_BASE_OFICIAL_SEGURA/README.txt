DOMINGOSBARBEARIA - Agenda 15 minutos e recorrência corrigida

Correções:
- Agenda agora mostra horários em blocos de 15 minutos.
- Agendamento às 17:15 aparece com nome, serviço e ações.
- Ao excluir agendamento recorrente, o sistema pergunta:
  OK = excluir todos os próximos da sequência
  Cancelar = excluir somente este horário
- Remove horários fantasmas/órfãos que travavam a agenda.
- Mantém o visual principal da barbearia.

Abra o index.html no tablet.
